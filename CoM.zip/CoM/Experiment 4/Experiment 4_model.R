
#this code, generates figures 5 & 8 and has the data from 4 and the elasticity OPoD model. 
#libraries 
library(nloptr)
library(cowplot)
library(ggplot2)
library(boot)
library(ggpubr)
library(sciplot) 
library(gtools)
library(data.table)
library(ez)

rm(list=ls())

dir = paste("~/Documents/GitHub/Experiment 4/") #change for your own OS
setwd(dir)
load('AllData.RData')



#Plotting
ggplot(GlobalLvlData, aes(x=as.factor(MassRatio),
                          y=as.numeric(Proportion_Ma), 
                          color = as.factor(CoR), 
                          group = as.factor(CoR))) +
  geom_hline(yintercept = .5, lty='longdash', col='grey') + 
  facet_grid(.~targetStartingPosIndex) +  
  stat_summary(fun.data='mean_se', geom='point', size = 2) +
  stat_summary(fun.data='mean_se', geom='line', size = 1) +
  stat_summary(fun.data='mean_se', geom='errorbar', width = .3, size = 1) +
  
  # Customize axis labels
  xlab(expression(M[a] / M[b])) +  # Subscript a and b
  ylab(expression(Proportion~choosing~italic(a))) +  # Italic a in the label
  
  # Customize the legend title (italic e)
  scale_color_discrete(name = expression(italic(e))) +
  
  # Use the classic theme
  theme_classic()




GlobalLvlData$targetStartingPosIndex <- as.factor(GlobalLvlData$targetStartingPosIndex)

ggplot(GlobalLvlData, aes(x=as.factor(MassRatio),
                          y=as.numeric(Proportion_Ma), color = as.factor(CoR), group = as.factor(CoR) )) +
  geom_hline(yintercept = .5, lty='longdash',col='grey') + 
  facet_grid(targetStartingPosIndex~SpeedType)+
  #geom_vline(xintercept = 1, lty='longdash',col='grey') + 
  stat_summary(fun.data='mean_se',geom='point') +
  stat_summary(fun.data='mean_se',geom='line') +
  stat_summary(fun.data='mean_se',geom='errorbar',width=.3) +
  theme_minimal() 


aov = ezANOVA(data = GlobalLvlData, dv =Proportion_Ma , wid = subjName, within = .(CoR,targetStartingPosIndex,MassRatio))





#modelling 
kpVal <-  0.6411235

#data collapsed over starting position. 
P1  <-ggplot(GlobalLvlData, aes(x=as.factor(MassRatio),
                                y=as.numeric(Proportion_Ma), 
                                color = as.factor(CoR), 
                                group = as.factor(CoR))) +
  geom_hline(yintercept = .5, lty='longdash', col='grey') + 
  stat_summary(fun.data='mean_se', geom='point', size = 2) +
  stat_summary(fun.data='mean_se', geom='line', size = 1) +
  stat_summary(fun.data='mean_se', geom='errorbar', width = .3, size = 1) +
  
  # Customize axis labels
  xlab(expression(M[a] / M[b])) +  # Subscript a and b
  ylab(expression(Proportion~choosing~italic(a))) +  # Italic a in the label
  
  # Customize the legend title (italic e)
  scale_color_discrete(name = expression(italic(e))) +
  
  # Use the classic theme
  theme_classic() + ggtitle("Data")+ ylim(0,1)

ModelData <- GlobalLvlData

#adjust vb and va
ModelData$Va <- ModelData$Va *-1
ModelData$Vb <- ModelData$Vb *-1

#get volume ratio as number 
#predict vb 
ModelData$vbp <-  ModelData$Ua  # predicted vb
#predict va
ModelData$vap <- 0   

#assign kp values
ModelData$kp <- kpVal
#combine vbp + vb 
ModelData$vb_IC <- sqrt(((ModelData$kp* ModelData$vbp)^2) +  ModelData$Vb^2)
#combine vap + va 
ModelData$va_IC <- 0
ModelData$va_IC[sign(ModelData$Va) == sign(ModelData$vap) ] = sign(ModelData$Va)* 
  sqrt(((ModelData$kp* ModelData$vap)^2) +  ModelData$Va^2)
ModelData$va_IC[sign(ModelData$Va) != sign(ModelData$vap) ] <- ModelData$Va

#get a mass ratio 
ModelData$PredMassRatio <- ModelData$vb_IC / (ModelData$Ua - ModelData$va_IC)

ModelData$delta = (ModelData$PredMassRatio-1)/(ModelData$PredMassRatio+1)





#fitting the decision noise

Bm2 = function(guess, delta, data){
  # Parameters
  dN = guess[1] # we are fitting the reliability of the prediction
  delta = delta
  
  # Model Equation
  
  pa = pnorm(delta, 0, dN) 
  
  simulation_error = sqrt(mean((pa-data)^2,na.rm=T)) #RMSE
  
  return (simulation_error)
}


# Setup for the optimizer

vec = NULL
guess = c(runif(1, min = 0.0, max = 100)) # initial guess for the fit parameter its a weight between 0 and 1 now. 
LB =  c(0.0)
UB =  c(100)
opt_print=0
options = list('algorithm'='NLOPT_LN_COBYLA',#'NLOPT_LN_BOBYQA',#'NLOPT_LN_NELDERMEAD',#'NLOPT_LN_SBPLX','NLOPT_LN_COBYLA'
               'print_level'=opt_print,
               'maxtime'=240) # better not take this long

# Do the Optimization
outdata=NULL
fitParams_bySubj = NULL
for (sb in unique(ModelData$subjName)){
  tempfit = subset(ModelData, subjName==sb)
  soln = nloptr(x0 = guess,
                eval_f = Bm2,
                lb = LB,
                ub = UB,
                opts=options,
                delta = tempfit$delta,
                data = tempfit$Proportion_Ma)
  
  tempfit$dN =soln$solution
  
  fitParams_bySubj=c(fitParams_bySubj,soln$solution)
  
  outdata = rbind(outdata, tempfit) 
}


ModelData$dN <- outdata$dN


ModelData$Pa <- pnorm(ModelData$delta, 0, ModelData$dN) 



P2  <-ggplot(ModelData, aes(x=as.factor(MassRatio),
                                y=Pa, 
                                color = as.factor(CoR), 
                                group = as.factor(CoR))) +
  geom_hline(yintercept = .5, lty='longdash', col='grey') + 
  stat_summary(fun.data='mean_se', geom='line', size = 1) +
  
  # Customize axis labels
  xlab(expression(M[a] / M[b])) +  # Subscript a and b
  ylab(expression(Proportion~choosing~italic(a))) +  # Italic a in the label
  
  # Customize the legend title (italic e)
  scale_color_discrete(name = expression(italic(e))) +
  
  # Use the classic theme
  theme_classic() + ggtitle("Data")+ ylim(0,1)



ggarrange(P1, P2, common.legend = TRUE)






