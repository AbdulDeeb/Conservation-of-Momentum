#this code, generates figure 4 and data from  Experiment 3
#libraries 

library(cowplot)
library(ggplot2)
library(boot)
library(ggpubr)
library(gtools)
library(data.table)
library(lme4)
library(quickpsy)
library(stringr)
library(sciplot) 

options(scipen=999)
rm(list=ls())

data = NULL
allData=NULL
subjectLvlsimple = NULL
subjectLvlAvg= NULL
simpleData2 = NULL

dir = paste("~/Documents/GitHub/Experiment 3/") #change for your own OS
setwd(dir)
load('data1.RData')
load('data2.RData')
load('data3.RData')
# Function to create the plots with unique colors and the required settings
create_plot <- function(data, title, color_palette) {
  ggplot(data, aes(x=as.factor(MassRatio), 
                   y=as.numeric(ProportionHeavier), 
                   color=as.factor(VolumeRatio), group=VolumeRatio)) +
    geom_hline(yintercept = .5, lty='longdash', col='grey') +
    stat_summary(fun.data='mean_se', geom='point', size = 3) +
    stat_summary(fun.data='mean_se', geom='line', size = 1) +
    stat_summary(fun.data='mean_se', geom='errorbar', width = .2, size = 1) +
    ylim(0, 1) +
    
    # Customize axis labels
    xlab(expression(M[a] / M[b]~"(Sequence 1)"~vs~M[a] / M[b]~"(Sequence 2)")) +  # Customize x-axis label
    ylab("Proportion Choosing Heavier") +
    
    # Apply theme_classic and adjust font sizes
    theme_classic() +
    ggtitle(title) +
    
    # Use the specified color palette for unique colors
    scale_color_manual(values = color_palette) +
    
    # Adjust font sizes for better visibility
    theme(
      axis.title = element_text(size = 14),
      axis.text = element_text(size = 12),
      legend.title = element_text(size = 14),
      legend.text = element_text(size = 12)
    )
}

# Define unique color palettes for each plot
colors_data1 <- c("#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e")  # Example color palette
colors_data2 <- c("#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00")  # Different color palette

# Create the plots with unique colors for data1 and data2
plot1 <- create_plot(data1, "Larger Vs Smaller", colors_data1)
plot2 <- create_plot(data2, "Smaller Vs Larger", colors_data2)

plot3 <- ggplot(data3, aes(x=as.factor(MassRatio), 
                           y=as.numeric(ProportionHeavier), 
                           group=VolumeRatio)) +
  geom_hline(yintercept = .5, lty='longdash', col='grey') +
  stat_summary(fun.data='mean_se', geom='point', size = 3, color = "black") +
  stat_summary(fun.data='mean_se', geom='line', size = 1, color = "black") +
  stat_summary(fun.data='mean_se', geom='errorbar', width = .2, color = "black", size = 1) +
  ylim(0, 1) +
  
  # Customize axis labels
  xlab(expression(M[a] / M[b]~"(Sequence 1)"~vs~M[a] / M[b]~"(Sequence 2)")) +  
  ylab("Proportion Choosing Heavier") +
  
  # Add a legend for VolumeRatio, even though the points and lines are all black
  scale_color_manual(values = c("black"), 
                     labels = c("Equal Condition"),
                     name = "Volume Ratio") +  # Add a black color with a custom label
  
  # Apply theme_classic and adjust font sizes
  theme_classic() +
  ggtitle("Equal (Baseline)") +
  
  # Adjust font sizes for better visibility
  theme(
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 12),
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12)
  )



# Display the plots
plot1 + theme(legend.position = "none")
plot2+ theme(legend.position = "none")
plot3



